const express = require('express');
const router = express.Router();
const db = require('../db/index');
const Transactions = db.transactions;
const Budgets = db.budgets;
const Users = db.users;
const auth = require('../middleware/auth');
const { Op, literal } = require('sequelize');
const moment = require('moment');
const exchangeRateService = require('../utils/exchangeRateService'); // Import your exchange rate service

const monthNamesToNumbers = {
    'january': '01',
    'february': '02',
    'march': '03',
    'april': '04',
    'may': '05',
    'june': '06',
    'july': '07',
    'august': '08',
    'september': '09',
    'october': '10',
    'november': '11',
    'december': '12',
};

router.get('/reports', auth, async (req, res) => {
    try {
        const { month, currency, year } = req.query;

        // Validate input
        if (!month || !currency || !year) {
            return res.status(400).json({ error: 'Month, currency, and year are required parameters' });
        }

        const monthNumber = monthNamesToNumbers[month.toLowerCase()];

        // Construct the start and end date for the month
        const startDate = moment(`${year}-${monthNumber}-01`).startOf('month');
        const endDate = moment(startDate).endOf('month');

        // Get user-specific transactions for the specified period
        const transactions = await Transactions.findAll({
            where: {
                userId: req.user.id,
                date: {
                    [Op.between]: [startDate.toDate(), endDate.toDate()],
                },
            },
        });

        // Get user-specific budget for the specified month
        const budget = await Budgets.findOne({
            where: {
                userId: req.user.id,
                month: month.toLowerCase(),
            },
        });

        // Convert amounts to the client-specified currency
        const transactionsInClientCurrency = transactions.map(transaction => {
            const convertedAmount = exchangeRateService.convert(transaction.amount, transaction.currency, currency);
            return { ...transaction.toJSON(), amount: convertedAmount, currency: currency };
        });

        const budgetInClientCurrency = {
            ...budget.toJSON(),
            amount: exchangeRateService.convert(budget.amount, budget.currency, currency),
            currency: currency,
        };

        // Now you have transactions and budget in the client-specified currency
        console.log('Transactions in client currency:', transactionsInClientCurrency);
        console.log('Budget in client currency:', budgetInClientCurrency);

        // ... (rest of the code remains the same)
        // Calculate total income and expenses in the requested currency
        const totalIncome = transactionsInClientCurrency
            .filter(transaction => transaction.category === 'Income')
            .reduce((sum, transaction) => sum + transaction.amount, 0);

        const totalExpenses = transactionsInClientCurrency
            .filter(transaction => transaction.category === 'Expense')
            .reduce((sum, transaction) => sum + transaction.amount, 0);

        const netBalance = totalIncome - totalExpenses;
        const remainingBudget = convertedBudgetAmount - totalExpenses;

        // Respond with the financial report
        res.send({
            totalIncome,
            totalExpenses,
            netBalance,
            remainingBudget,
            transactions: transactionsInClientCurrency,
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

module.exports = router;








// const currentDate = new Date();
// const currentMonth = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}`;
// const month = req.params.month
// const currency = req.params.currency

// Get total income and expenses for the specified period
// const totalIncome = await Transactions.sum('amount', {
//     where: {
//         category: 'Income',
//         date: { $like: `${currentMonth}%` },
//     },
// });

// const totalExpenses = await Transactions.sum('amount', {
//     where: {
//         category: 'Expense',
//         date: { $like: `${currentMonth}%` },
//     },
// });

// const budget = await Budgets.findOne({ where: { month: currentMonth } });

// const report = {
//     totalIncome: totalIncome || 0,
//     totalExpenses: totalExpenses || 0,
//     budget: budget ? budget.amount : 0,
//     remainingBudget: budget ? budget.amount - totalExpenses : 0,
// };