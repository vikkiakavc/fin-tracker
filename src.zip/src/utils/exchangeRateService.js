const exchangeRatesApi = require('exchange-rates-api');

async function fetchExchangeRate(fromCurrency, toCurrency) {
  const rate = await exchangeRatesApi.convert(1, { from: fromCurrency, to: toCurrency });
  return rate[toCurrency];
}

// Function to convert amount from one currency to another
async function convert(amount, fromCurrency, toCurrency) {
  const exchangeRate = await fetchExchangeRate(fromCurrency, toCurrency);
  const convertedAmount = amount * exchangeRate;

  return parseFloat(convertedAmount.toFixed(2)); // Round to two decimal places
}

module.exports = {
  convert,
};
